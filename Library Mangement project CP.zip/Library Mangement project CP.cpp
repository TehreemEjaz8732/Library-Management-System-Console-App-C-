//Password for Librarian login is 123
#include <iostream>
#include <stdlib.h>
#include <string>
#include <fstream>
using namespace std;
int loginSystemLibararian();
void bookList();
void librarianBookDetails();
void BookDetails();
void librarianMenu();
void student();
void Faculty();
void studentDetails();

struct studentlist
{
	string name;
	string studentId;
	string bookName;
	int  serialNo;
	string issueDate;
	string returnDate;

};

int main()
{
	int choice;
	cout << "\n\n*********************************************************************************************************************" << endl;
	cout << "\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t \t\t\t\t       LIBARARY MANAGEMENT SYSTEM " << "\n\n";
	cout << "*********************************************************************************************************************" << endl;
	cout << "\n\t\t\t\t   >>> Choose any option to login >>>" << endl;
	cout << "\n\t\t\t\t\t   1. Librarian" << endl;
	cout << "\n\t\t\t\t\t   2. Student " << endl;
	cout << "\n\t\t\t\t\t   3. Faculty " << endl;
	cout << "\n\t\t\t\t\t   4. Exit program " << "\n\n";
	cout << "\n\t\t\t\t\t   Enter your choice: ";
	cin >> choice;
	system("cls");
	cout << "\n\n";
	switch (choice)
	{
	case 1:
		loginSystemLibararian();
		system("cls");
		librarianMenu();
		break;
	case 2:
		student();
		bookList();
		BookDetails();
		break;
	case 3:
		Faculty();
		bookList();
		BookDetails();
		break;
	case 4:
		exit(1);
		break;
	}
	return 0;
}

int loginSystemLibararian()
{
	int pass, noOfTimes = 0;
	cout << "\n\t\t\t\t   ---------- Admin Login -------\n" << endl;
	cout << "\t\t\t\t\t    User name: " << "Librarian" << endl;
	cout << "\n\t\t\t\t\t    Enter your password: ";
	cin >> pass;
	while (pass != 123 && noOfTimes <= 2)
	{
		cout << "\n\n";
		cout << "\t\t\t\t\t  Incorrect Password!!" << endl;
		cout << "\t\t\t\t\t  Enter your password again: ";
		cin >> pass;

	}

	return 0;
}
void bookList()
{
	ofstream MyFile("libr.txt");
	MyFile << "\n\n\t\t\t\t\t  BOOK LIST\n\n";
	MyFile << "\t\t\t\t\t  1. Phsics\n\n ";
	MyFile << "\t\t\t\t\t  2. Maths\n\n ";
	MyFile << "\t\t\t\t\t  3. chemistry\n\n ";
	MyFile << "\t\t\t\t\t  4. Pshycology\n\n ";
	MyFile << "\t\t\t\t\t  5. English\n\n ";
	MyFile.close();

	string myText;
	ifstream MyReadFile("libr.txt");
	while (getline(MyReadFile, myText))
	{
		cout << myText << endl;
	}
	MyReadFile.close();

}

void librarianBookDetails()
{
	int no;
	cout << "\n\t\t\t\t\t  Enter your book choice: ";
	cin >> no;
	system("cls");
	cout << "\n\n";
	cout << "\n\t\t\t\t\t  Book Details\n\n";
	switch (no)
	{
	case 1:
		cout << "\t\t\t\t\t  Physics\n";
		cout << "\t\t\t\t\t  Sr. No: 3452\n ";
		cout << "\t\t\t\t\t  Price: Rs.400 \n";
		cout << "\t\t\t\t\t  Author Name: Newton\n";
		cout << "\t\t\t\t\t  Total Pages: 390\n";
		cout << "\t\t\t\t\t  Total Quantity: 4\n";
		break;
	case 2:
		cout << "\t\t\t\t\t  Maths\n";
		cout << "\t\t\t\t\t  Sr. No: 5678\n ";
		cout << "\t\t\t\t\t  Price: Rs.400 \n";
		cout << "\t\t\t\t\t  Author Name: Thomas Finney\n";
		cout << "\t\t\t\t\t  Total Pages: 200\n";
		cout << "\t\t\t\t\t  Total Quantity: 7\n";
		break;
	case 3:
		cout << "\t\t\t\t\t  chemistry\n";
		cout << "\t\t\t\t\t  Sr. No: 5432\n ";
		cout << "\t\t\t\t\t  Price: Rs.400 \n";
		cout << "\t\t\t\t\t  Author Name: Bohr smith\n";
		cout << "\t\t\t\t\t  Total Pages: 300\n";
		cout << "\t\t\t\t\t  Total Quantity: 2\n";
		break;
	case 4:
		cout << "\t\t\t\t\t  Pshycology\n";
		cout << "\t\t\t\t\t  Sr. No: 3445\n ";
		cout << "\t\t\t\t\t  Price: Rs.400 \n";
		cout << "\t\t\t\t\t  Author Name: William\n";
		cout << "\t\t\t\t\t  Total Pages: 390\n";
		cout << "\t\t\t\t\t  Total Quantity: 3\n";
		break;
	case 5:
		cout << "\t\t\t\t\t  English\n";
		cout << "\t\t\t\t\t  Sr. No: 3789\n ";
		cout << "\t\t\t\t\t  Price: Rs.200 \n";
		cout << "\t\t\t\t\t  Author Name: Charles\n";
		cout << "\t\t\t\t\t  Total Pages: 205\n";
		cout << "\t\t\t\t\t  Total Quantity: 5\n";
		break;
	}
}

void student()
{
	cout << "\n\t\t\t\t   ---------- Student Login -------\n" << endl;
	cout << "\t\t\t\t\t  User name: " << "Student" << endl;


}

void BookDetails()
{
	int no;
	cout << "\n\t\t\t\t\t  Enter your book choice: ";
	cin >> no;
	system("cls");
	cout << "\n\n\t\t\t\t\t  Book Deatils\n\n";
	switch (no)
	{
	case 1:
		cout << "\t\t\t\t\t  Physics\n";
		cout << "\t\t\t\t\t  Sr. No: 3452\n ";
		cout << "\t\t\t\t\t  Author Name: Newton \n";
		break;
	case 2:
		cout << "\t\t\t\t\t  Maths\n";
		cout << "\t\t\t\t\t  Sr. No: 5678\n ";
		cout << "\t\t\t\t\t  Author Name: Thomas Finney\n";
		break;
	case 3:
		cout << "\t\t\t\t\t  chemistry\n";
		cout << "\t\t\t\t\t  Sr. No: 5432\n ";
		cout << "\t\t\t\t\t  Author Name: Bohr smith\n";
		break;
	case 4:
		cout << "\t\t\t\t\t  Pshycology\n";
		cout << "\t\t\t\t\t  Sr. No: 3445\n ";
		cout << "\t\t\t\t\t  Author Name: William\n";
		break;
	case 5:
		cout << "\t\t\t\t\t  English\n";
		cout << "\t\t\t\t\t  Sr. No: 3789\n ";
		cout << "\t\t\t\t\t  Author Name: Charles \n";
		break;
	}
}
void librarianMenu()
{
	int no;
	cout << "\n\n\t\t\t\t\t        MENU\n" << endl;
	cout << "\t\t\t\t\t   1. Book List\n" << endl;
	cout << "\t\t\t\t\t   2. Book Details\n" << endl;
	cout << "\t\t\t\t\t   3. Issue books\n\n" << endl;
	cout << "\t\t\t\t\t   Enter your choice: ";
	cin >> no;
	system("cls");
	cout << "\n";
	if (no == 1)
	{
		bookList();
	}
	else if (no == 2)
	{
		bookList();
		librarianBookDetails();
	}
	else if (no == 3)
	{
		studentDetails();
	}
}
void studentDetails()
{
	studentlist studentDetails[5];
	char choice;
	int a = 0;
	for (int i = 0; i < 5; i++)
	{
		cin.ignore();
		cout << "\n\n\t\t\t\t\t   Enter the student name: ";
		getline(cin, studentDetails[i].name);
		cout << "\t\t\t\t\t   Enter the student ID: ";
		getline(cin, studentDetails[i].studentId);
		cout << "\t\t\t\t\t   Enter the Book name: ";
		getline(cin, studentDetails[i].bookName);
		cout << "\t\t\t\t\t   Enter the Serial number: ";
		cin >> studentDetails[i].serialNo;
		cin.ignore();
		cout << "\t\t\t\t\t   Enter the Issue Date: ";
		getline(cin, studentDetails[i].issueDate);
		cout << "\t\t\t\t\t   Enter the Return Date: ";
		getline(cin, studentDetails[i].returnDate);
		a++;
		cout << endl;
		system("cls");
		cout << "\n\n\t\t\t\t\tDo you want to issue a book to another student? ";
		cin >> choice;
		if (choice == 'n' || choice == 'N')
			break;
		cout << endl;
	}
	ofstream MyFile;
	MyFile.open("lib.txt", ios::app);
	for (int i = 0; i < a; i++)
	{
		MyFile << "\n\nStudent Name: " << studentDetails[i].name << "\n";
		MyFile << "Student ID: " << studentDetails[i].studentId << "\n";
		MyFile << "Book Name: " << studentDetails[i].bookName << "\n";
		MyFile << "Serial Number: " << studentDetails[i].serialNo << "\n";
		MyFile << "Issue date: " << studentDetails[i].issueDate << "\n";
		MyFile << "Return Date: " << studentDetails[i].returnDate << "\n\n";
	}
	MyFile.close();
	system("cls");
	cout << "\n\t\t\t\t\t   RECORD SAVED!\n\n";
	char ch;
	cout << "\t\t\t\t\t   Do you want to review the Saved Record? ";
	cin >> ch;
	system("cls");
	if (ch == 'y' || ch == 'Y')
	{
		string myText;
		ifstream MyReadFile("lib.txt");
		for (int i = 0; i < a; i++)
		{
			while (getline(MyReadFile, myText))
			{
				cout << "\t\t\t\t\t   " << myText << "\n";
			}
			cout << endl;
		}
		MyReadFile.close();
	}
}

void Faculty()
{
	cout << "\n\t\t\t\t   ---------- Faculty Login -------\n" << endl;
	cout << "\t\t\t\t\t  User name: " << "Faculty" << endl;
}

